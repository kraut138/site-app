import React, { useState, useEffect, useCallback } from "react";
import PlatformShell from "./platform/PlatformShell.jsx";
import PortalDashboard from "./platform/PortalDashboard.jsx";
import QrGenerator from "./platform/QrGenerator.jsx";
import OperationsHub from "./components/OperationsHub.jsx";
import VoiceInspection from "./components/VoiceInspection.jsx";
import QrBoardScreen from "./components/QrBoardScreen.jsx";
import Glossary from "./components/Glossary.jsx";
import Buildings from "./components/Buildings.jsx";
import SiteLayout from "./components/SiteLayout.jsx";
import UnitInfo from "./components/UnitInfo.jsx";
import LoginScreen from "./components/LoginScreen.jsx";
import SafetyOverview from "./components/SafetyOverview.jsx";
import QrUnitScreen from "./components/QrUnitScreen.jsx";
import { Toast } from "./components/UI.jsx";
import { ROLES, isAdminRole, isViewAllowed, normalizeRole, defaultViewFor } from "./data.js";
import * as api from "./api.js";
import { subscribeAuth, fetchUserProfile, logOut, updateUserLanguage } from "./auth.js";
import { LanguageProvider } from "./LanguageContext.jsx";
import { DEFAULT_LANGUAGE } from "./i18n.js";
import { readUnitDeepLink, clearUnitDeepLinkFromUrl, readQrBoardLink } from "./qr.js";
import { readViewLink, clearViewLinkFromUrl } from "./viewLink.js";

// 페이지가 처음 로드될 때 딱 한 번만 읽는다 - QR 스캔으로 들어온 경우 여기에 값이 담긴다.
// 이 값이 있으면 로그인/사이드바 전체를 건너뛰고 QrUnitScreen(모바일 전용 화면)을 바로 보여준다.
// QR 기록판 QR(?qr=코드)로 들어온 경우도 같은 방식으로 로그인 없이 전용 화면만 보여준다. 두 QR이 함께 있으면 기록판이 우선이다.
const initialQrBoardId = readQrBoardLink();
const initialDeepLink = initialQrBoardId ? null : readUnitDeepLink();
// 주소 끝(#glossary)으로 들어온 "화면 바로가기"도 한 번만 읽는다(첫 화면의 '실제 앱 용어 DB 열기' 버튼). 로그인한 뒤 그 화면부터 보여준다. QR로 들어온 경우엔 쓰지 않는다.
const initialViewLink = initialQrBoardId || initialDeepLink ? null : readViewLink();

export default function App() {
  // authUser: Firebase Auth 로그인 여부. userProfile: Firestore에 저장된 이름/역할.
  // trueRole은 실제 계정 권한(로그인 시 그대로 고정), role은 화면에 실제 적용되는 값이다.
  // 관리자(소장) 계정만 viewAsRole로 "미리보기" 역할을 골라 role을 바꿔볼 수 있다 - Firestore에 저장된
  // 진짜 권한(trueRole)은 절대 안 바뀌므로, 하도급사 계정은 이 기능으로 권한이 올라갈 수 없다.
  // 역할은 하도급사/관리자 두 가지뿐이라, 저장된 값이 예전 "감리자"이거나 알 수 없는 값이어도 normalizeRole이 둘 중 하나로 맞춰준다.
  const [authUser, setAuthUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [viewAsRole, setViewAsRole] = useState(null);
  const trueRole = userProfile ? normalizeRole(userProfile.role) : null;
  const role = trueRole === ROLES.SUPER && viewAsRole ? viewAsRole : trueRole;
  const lang = userProfile?.language || DEFAULT_LANGUAGE;

  async function handleChangeLanguage(nextLang) {
    setUserProfile((prev) => (prev ? { ...prev, language: nextLang } : prev));
    if (authUser) {
      try {
        await updateUserLanguage(authUser.uid, nextLang);
      } catch {
        // 저장에 실패해도 화면 표시 언어는 이미 바뀐 상태로 둔다 - 다음 로그인 때만 이전 언어로 보일 뿐이다.
      }
    }
  }
  // 고른 화면(view)을 지금 역할이 볼 수 없으면 그 역할의 첫 화면(관리자: 대시보드, 하도급사: 음성 보고)을 대신 보여 준다.
  // 그래서 모드를 바꿨다가 돌아와도, #glossary 같은 바로가기로 들어와도 빈 화면이 되지 않는다.
  const [view, setView] = useState(initialViewLink || null);
  const [unitTarget, setUnitTarget] = useState(null);
  const [buildings, setBuildings] = useState([]);
  const [inspections, setInspections] = useState([]);
  const [ncrs, setNcrs] = useState([]);
  const [unitNotes, setUnitNotes] = useState([]);
  const [checklistItems, setChecklistItems] = useState([]);
  const [equipment, setEquipment] = useState([]);
  const [unitFloorPlans, setUnitFloorPlans] = useState([]);
  const [siteSettings, setSiteSettings] = useState({});
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [toast, setToast] = useState("");

  const notify = useCallback((msg) => setToast(msg), []);

  function handleNavigateToUnit(buildingId, floor, unit) {
    // 골구도와 호실 정보는 둘 다 감리단 전용 화면이라, 여기서 이동하는 건 별도 예외 없이 항상 허용된다.
    setUnitTarget({ buildingId, floor, unit });
    setView("unitinfo");
  }

  useEffect(() => {
    // 딥링크 값은 이미 모듈 최상단 상수(initialDeepLink)에 담겨 있으니, 주소창은 바로 정리해도 된다.
    // 정리해두지 않으면 나중에 다른 화면을 보다가 새로고침했을 때 계속 이 호실로 튕기게 된다.
    if (initialDeepLink) clearUnitDeepLinkFromUrl();
    // 화면 바로가기(#glossary)도 같은 이유로 바로 지운다 - 안 지우면 다른 화면을 보다가 새로고침했을 때 계속 그 화면으로 돌아간다.
    if (initialViewLink) clearViewLinkFromUrl();
  }, []);

  useEffect(() => {
    // QR 스캔으로 들어온 경우엔 로그인 없이 바로 QrUnitScreen / QrBoardScreen을 보여주므로 인증 상태를 볼 필요가 없다.
    if (initialDeepLink || initialQrBoardId) {
      setAuthChecked(true);
      return;
    }
    const unsubscribe = subscribeAuth(async (user) => {
      setAuthUser(user);
      if (user) {
        try {
          const profile = await fetchUserProfile(user.uid, user.email);
          setUserProfile(profile);
        } catch {
          setUserProfile({ email: user.email, name: "", role: ROLES.SUB });
        }
      } else {
        setUserProfile(null);
      }
      setAuthChecked(true);
    });
    return unsubscribe;
  }, []);

  async function handleLogout() {
    await logOut();
    setViewAsRole(null);
  }

  const activeView = role ? (view && isViewAllowed(view, role) ? view : defaultViewFor(role)) : view;

  useEffect(() => {
    // QR 기록판 화면은 공사 데이터가 필요 없으니, 스캔한 사람의 기기에서 전체 데이터를 읽어오지 않는다.
    if (initialQrBoardId) {
      setLoading(false);
      return undefined;
    }
    let alive = true;
    api
      .fetchBootstrap()
      .then((data) => {
        if (!alive) return;
        setBuildings(data.buildings || []);
        setInspections(data.inspections || []);
        setNcrs(data.ncrs || []);
        setUnitNotes(data.unitNotes || []);
        setChecklistItems(data.checklistItems || []);
        setEquipment(data.equipment || []);
        setUnitFloorPlans(data.unitFloorPlans || []);
        setSiteSettings(data.siteSettings || {});
      })
      .catch((err) => alive && setLoadError(err.message))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, []);

  async function handleCreateBuilding(data) {
    const created = await api.createBuilding(data);
    setBuildings((prev) => [...prev, created]);
  }

  async function handleDeleteBuilding(id) {
    await api.deleteBuilding(id);
    setBuildings((prev) => prev.filter((b) => b.id !== id));
  }

  async function handleUpdateBuilding(id, data) {
    const updated = await api.updateBuilding(id, data);
    setBuildings((prev) => prev.map((b) => (b.id === id ? updated : b)));
    return updated;
  }

  async function handleUpdateSiteSettings(data) {
    const updated = await api.updateSiteSettings(data);
    setSiteSettings(updated);
    return updated;
  }

  async function handleCreateUnitFloorPlan(data) {
    const created = await api.createUnitFloorPlan(data);
    setUnitFloorPlans((prev) => [...prev, created]);
    return created;
  }

  async function handleUpdateUnitFloorPlan(id, data) {
    const updated = await api.updateUnitFloorPlan(id, data);
    setUnitFloorPlans((prev) => prev.map((p) => (p.id === id ? updated : p)));
    return updated;
  }

  async function handleDeleteUnitFloorPlan(id) {
    await api.deleteUnitFloorPlan(id);
    setUnitFloorPlans((prev) => prev.filter((p) => p.id !== id));
  }

  async function handleCreateUnitNote(data) {
    const created = await api.createUnitNote(data);
    setUnitNotes((prev) => [...prev, created]);
    return created;
  }

  async function handleDeleteUnitNote(id) {
    await api.deleteUnitNote(id);
    setUnitNotes((prev) => prev.filter((n) => n.id !== id));
  }

  async function handleCreateChecklistItem(data) {
    const created = await api.createChecklistItem(data);
    setChecklistItems((prev) => [...prev, created]);
    return created;
  }

  async function handleDeleteChecklistItem(id) {
    await api.deleteChecklistItem(id);
    setChecklistItems((prev) => prev.filter((i) => i.id !== id));
  }

  async function handleResetChecklistCategory(categoryId, items) {
    const created = await api.resetChecklistCategory(categoryId, items);
    setChecklistItems((prev) => [...prev.filter((i) => i.categoryId !== categoryId), ...created]);
  }

  async function handleReorderChecklistItems(categoryId, orderedIds) {
    // 화면 반응성을 위해 로컬 순서부터 먼저 반영하고, 실패하면 되돌린다.
    const prevItems = checklistItems;
    const orderMap = new Map(orderedIds.map((id, order) => [id, order]));
    setChecklistItems((prev) => prev.map((i) => (orderMap.has(i.id) ? { ...i, order: orderMap.get(i.id) } : i)));
    try {
      await api.reorderChecklistItems(categoryId, orderedIds);
    } catch (err) {
      setChecklistItems(prevItems);
      throw err;
    }
  }

  async function handleUpdateEquipmentStatus(id, data) {
    const updated = await api.updateEquipmentStatus(id, data);
    setEquipment((prev) => prev.map((eq) => (eq.id === id ? updated : eq)));
    return updated;
  }

  async function handleCreateInspection(data) {
    const created = await api.createInspections(data);
    setInspections((prev) => [...prev, ...created]);
    return created;
  }

  async function handleUpdateInspectionStatus(id, data) {
    const res = await api.updateInspectionStatus(id, data);
    setInspections((prev) => prev.map((i) => (i.id === id ? res.inspection : i)));
    if (res.ncr) {
      setNcrs((prev) => [...prev, res.ncr]);
    }
    return res;
  }

  async function handleBatchUpdateInspectionStatus(ids, data) {
    const results = await Promise.all(ids.map((id) => api.updateInspectionStatus(id, data)));
    const byId = new Map(results.map((r) => [r.inspection.id, r.inspection]));
    setInspections((prev) => prev.map((i) => (byId.has(i.id) ? byId.get(i.id) : i)));
    const newNcrs = results.filter((r) => r.ncr).map((r) => r.ncr);
    if (newNcrs.length > 0) {
      setNcrs((prev) => [...prev, ...newNcrs]);
    }
    return results;
  }

  async function handleUpdateNcrStatus(id, data) {
    const res = await api.updateNcrStatus(id, data);
    setNcrs((prev) => prev.map((n) => (n.id === id ? res : n)));
    return res;
  }

  const badges = {
    pending: inspections.filter((i) => i.status === "대기").length,
    ncr: ncrs.filter((n) => n.status !== "완료").length,
    safetyNcr: ncrs.filter((n) => n.categoryId === "safety" && n.status !== "완료").length,
    equipmentPending: equipment.filter((eq) => eq.status === "대기").length,
  };
  badges.operations = badges.pending + badges.ncr;
  // 안전 현황 탭에서 처리할 수 있는 것만 센다: 안전 NCR + 승인 대기 건설기계(인력 승인 화면은 메뉴에서 없앴다)
  badges.safetyTotal = badges.safetyNcr + badges.equipmentPending;

  let content;
  if (initialQrBoardId) {
    content = <QrBoardScreen qrId={initialQrBoardId} />;
  } else if (!authChecked) {
    content = <CenterMessage>불러오는 중…</CenterMessage>;
  } else if (!initialDeepLink && !authUser) {
    content = (
      <LoginScreen
        onSignedUp={(profile) => {
          setAuthUser({ uid: profile.uid, email: profile.email });
          setUserProfile(profile);
        }}
      />
    );
  } else if (loading || (!initialDeepLink && !userProfile)) {
    // 로그인은 됐지만 역할(프로필)을 아직 못 읽은 짧은 순간에도 여기서 기다린다 - 역할 없이 화면을 그리면 메뉴가 비어 보인다.
    content = <CenterMessage>불러오는 중…</CenterMessage>;
  } else if (loadError) {
    content = (
      <CenterMessage>
        데이터를 불러오지 못했습니다.
        <br />
        {loadError}
      </CenterMessage>
    );
  } else if (initialDeepLink) {
    // QR로 특정 호실을 스캔해 들어온 경우: 로그인·사이드바 없이 이 화면만 보여준다.
    content = (
      <QrUnitScreen
        buildings={buildings}
        inspections={inspections}
        checklistItems={checklistItems}
        unitNotes={unitNotes}
        unitFloorPlans={unitFloorPlans}
        target={initialDeepLink}
        onCreateNote={handleCreateUnitNote}
        onDeleteNote={handleDeleteUnitNote}
        onCreateConfirmationRequest={handleCreateInspection}
      />
    );
  } else {
    content = (
      <>
        <PlatformShell
          role={role}
          trueRole={trueRole}
          onSetViewAsRole={setViewAsRole}
          userProfile={userProfile}
          onLogout={handleLogout}
          view={activeView}
          setView={setView}
          badges={badges}
        >
          {activeView === "dashboard" && (
            <PortalDashboard buildings={buildings} inspections={inspections} ncrs={ncrs} notify={notify} />
          )}
          {activeView === "qrgen" && <QrGenerator buildings={buildings} notify={notify} onGoBuildings={() => setView("buildings")} />}
          {activeView === "operations" && (
            <OperationsHub
              key={role}
              role={role}
              badges={badges}
              buildings={buildings}
              inspections={inspections}
              ncrs={ncrs}
              checklistItems={checklistItems}
              unitFloorPlans={unitFloorPlans}
              onCreateConfirmationRequest={handleCreateInspection}
              onUpdateInspectionStatus={handleUpdateInspectionStatus}
              onBatchUpdateInspectionStatus={handleBatchUpdateInspectionStatus}
              onUpdateNcrStatus={handleUpdateNcrStatus}
              onCreateChecklistItem={handleCreateChecklistItem}
              onDeleteChecklistItem={handleDeleteChecklistItem}
              onResetChecklistCategory={handleResetChecklistCategory}
              onReorderChecklistItems={handleReorderChecklistItems}
              notify={notify}
            />
          )}
          {activeView === "voice" && (
            <VoiceInspection
              compact
              buildings={buildings}
              userName={(userProfile && (userProfile.name || userProfile.email)) || ""}
              notify={notify}
              checklistItems={checklistItems}
            />
          )}
          {activeView === "glossary" && <Glossary adminName={(userProfile && (userProfile.name || userProfile.email)) || ""} notify={notify} />}
          {activeView === "safety" && (
            <SafetyOverview
              role={role}
              buildings={buildings}
              inspections={inspections}
              ncrs={ncrs}
              equipment={equipment}
              unitFloorPlans={unitFloorPlans}
              onUpdateNcrStatus={handleUpdateNcrStatus}
              onUpdateEquipmentStatus={handleUpdateEquipmentStatus}
              notify={notify}
            />
          )}
          {activeView === "unitinfo" && (
            <UnitInfo
              buildings={buildings}
              inspections={inspections}
              checklistItems={checklistItems}
              unitNotes={unitNotes}
              unitFloorPlans={unitFloorPlans}
              initialTarget={unitTarget}
              onConsumeInitialTarget={() => setUnitTarget(null)}
              onCreateNote={handleCreateUnitNote}
              onDeleteNote={handleDeleteUnitNote}
              notify={notify}
              canEdit={isAdminRole(role)}
              userName={(userProfile && (userProfile.name || userProfile.email)) || ""}
            />
          )}
          {activeView === "buildings" && (
            <Buildings
              buildings={buildings}
              onCreate={handleCreateBuilding}
              onDelete={handleDeleteBuilding}
              onUpdateBuilding={handleUpdateBuilding}
              canEdit={isAdminRole(role)}
              unitFloorPlans={unitFloorPlans}
              onCreateFloorPlan={handleCreateUnitFloorPlan}
              onUpdateFloorPlan={handleUpdateUnitFloorPlan}
              onDeleteFloorPlan={handleDeleteUnitFloorPlan}
              siteSettings={siteSettings}
              onUpdateSiteSettings={handleUpdateSiteSettings}
              notify={notify}
            />
          )}
          {activeView === "sitelayout" && (
            <SiteLayout buildings={buildings} checklistItems={checklistItems} inspections={inspections} onNavigateToUnit={handleNavigateToUnit} />
          )}
        </PlatformShell>
        <Toast message={toast} onDone={() => setToast("")} />
      </>
    );
  }

  return (
    <LanguageProvider lang={lang} onChange={handleChangeLanguage}>
      {content}
    </LanguageProvider>
  );
}

function CenterMessage({ children }) {
  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--ink-soft)", fontSize: 14, textAlign: "center" }}>
      {children}
    </div>
  );
}
